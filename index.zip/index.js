
const butt = document.getElementById("cell"); 
let turn = true;
class Board {
    constructor() {
        this.cells = [];
        this.row = 5;
        this.col = 5;
        this.Setup();
    }
    Setup() {
        const layout = document.getElementById("board");
        for(let y = 0 ; y < this.row; y++)
        {
            let r = [];
            for(let x = 0; x < this.col; x++)
            {
                let cell = new Cell({x, y, value: null,board: this });
                r.push(cell);
                layout.appendChild(cell.element);                
            }
            this.cells.push(r);
        }
    }
    isValidPosition(position = []) {
        let x = position[0];
        let y = position[1];
        return ! (x < 0 || x >= this.col || y < 0 || y >= this.row);
    }

    ScanCheck(checkCell) {
        let vertical = [];
        let horizontal = [];
        let main_diagonal = [];
        let sub_diagonal = [];

        let result = [];
        const curPosition = checkCell.position
        const val = checkCell.value        ;
        let x = curPosition[0], y = curPosition[1];
        //init
        for(let i = 2; i >= 0; i--)
        {
            
            if(this.isValidPosition([x,y-i]))
                vertical.push(this.cells[y-i][x]);
            
            if(this.isValidPosition([x-i,y]))
                horizontal.push(this.cells[y][x-i]);

            if(this.isValidPosition([x-i,y-i]))
                main_diagonal.push(this.cells[y-i][x-i]);

            if(this.isValidPosition([x+i,y -i]))
                sub_diagonal.push(this.cells[y-i][x+i]);
        }
        console.log(vertical, horizontal, main_diagonal, sub_diagonal);
        

        for(let start = 1; start <= 3; start++){
            const v = vertical.filter(o => o.value === val).length;
            const h = horizontal.filter(o => o.value === val).length;
            const mD = main_diagonal.filter(o => o.value === val).length;
            const sD = sub_diagonal.filter(o => o.value === val).length;
            
            if(v >= 3) result.push(vertical);
            if(h >= 3) result.push(horizontal);
            if(mD >= 3) result.push(main_diagonal);
            if(sD >= 3) result.push(sub_diagonal);
            
            if(result.length >= 1)
            {
                alert(result);
                return result;

            }
        
            if(vertical.length >= 3) vertical.shift();
            if(main_diagonal.length >= 3) main_diagonal.shift();
            if(horizontal.length >= 3) horizontal.shift();
            if(sub_diagonal.length >=3) sub_diagonal.shift();
            
            let nextX = curPosition[0], nextY = curPosition[1] + start;
            if(this.isValidPosition([nextX,nextY]))
                vertical.push(this.cells[nextY][nextX])
            
            nextX = curPosition[0]+ start, nextY = curPosition[1];
            if(this.isValidPosition([nextX, nextY]))
                horizontal.push(this.cells[nextY][nextX]);

            nextX = curPosition[0]+ start, nextY = curPosition[1] + start;
            if(this.isValidPosition([nextX, nextY]))
                main_diagonal.push(this.cells[nextY][nextX]);

            nextX = curPosition[0]- start, nextY = curPosition[1] + start;
            if(this.isValidPosition([nextX, nextY]))
                sub_diagonal.push(this.cells[nextY][nextX]);

        }
        console.log(vertical, horizontal, main_diagonal, sub_diagonal);
        return [];
    }
}

class Cell {
    constructor(props = {x: 0, y: 0, value: null, board}) {
        this.position = [props.x,props.y];
        this.value = props.value;
        this.board = props.board;
        this.element = butt.cloneNode(true);
        this.element.addEventListener("click", () => this.onClick());
    }

    onClick() {
        if(this.value != null)
            return;
        this.value = turn;
        this.element.textContent = this.value;
        board.ScanCheck(this);
        turn = !turn;
    }


}

let board = new Board();